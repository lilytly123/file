# Claude Code 项目指引

## 项目概述

飞书中继 API 服务，伪装成 OpenAI 兼容的大模型 API。收到请求后通过飞书群转发，等待群里的 AI 服务处理后返回结果。

## 运行环境

- **机器**: 腾讯内网 VM `21.214.68.129`
- **Python**: `python3.12`
- **服务端口**: 9090（wechat-claude-bot 在 8080）
- **日志**: `/tmp/feishu-relay.log`
- **启动**: `/root/feishu-relay/start.sh`

## 飞书配置

- **App ID**: `cli_a920d2534b78dcbd`（独立于 wechat-claude-bot 的飞书应用）
- **App Secret**: `bcAO7dO6vIftraPNBCKOMbTJcdSc8WlP`
- **群 Chat ID**: `oc_f5d386fdffce10b8c13af589dd62e833`（与 wechat-claude-bot 同群）

## 关联服务

- **wechat-claude-bot**（`/root/wechat-claude-bot`，端口 8080）：群里的 AI 处理服务，接收 `prompt_request.txt`，调用 Claude，返回 `prompt_response.txt`
- 两个服务通过同一个飞书群通信，各自使用不同的飞书应用

## 请求匹配机制

1. 发送 `prompt_request.txt` 到群，获得 `message_id`
2. 每 3 秒轮询群最近 10 条消息（`GET /im/v1/messages`）
3. 找到 `msg_type=file`、`file_name=prompt_response.txt`、`parent_id` 匹配的消息
4. 下载文件内容解析为 JSON 返回
5. 超时 600 秒后返回 504

## 已知坑点

- **飞书 WebSocket 不推送其他 app 的消息**: 这是飞书平台限制，app A 发的消息不会触发 app B 的 WebSocket 事件。因此本服务和 wechat-claude-bot 都用轮询而非 WebSocket 来发现新文件
- **飞书 reply API 不存在**: `/im/v1/messages/{id}/reply` 返回 404，需要用列表接口 + `parent_id` 过滤
- **model ID**: relay 会将 model 强制设为 `anthropic.claude-opus-4-6-v1`，避免传入非法 ID 导致空响应
- **空响应**: 轮询时检查 response content 是否非空，空的跳过继续等待

## 开发流程

1. 改完代码先测试，展示结果给用户确认
2. 确认后再重启服务
3. 同步更新 README.md 和 CLAUDE.md

## 开发命令

```bash
# 启动/重启
/root/feishu-relay/start.sh

# 查看日志
tail -f /tmp/feishu-relay.log

# 测试
bash /root/feishu-relay/test.sh

# 手动停止
pkill -f "python3.12 /root/feishu-relay/app.py"
```
