# feishu-relay

伪装成 OpenAI 兼容大模型 API 的飞书中继服务。

你（或任何 OpenAI 兼容的工具）发请求过来，它帮你把请求转发到飞书群里，等群里的 AI 服务处理完，再把结果返回给你。你感觉就像在调一个正常的大模型 API。

## 它干了什么

```
你的请求 → feishu-relay → 飞书群 → AI 服务处理 → 飞书群 → feishu-relay → 你收到回复
```

具体步骤：
1. 你发一个 OpenAI 格式的请求到 `http://<服务地址>:9090/v1/chat/completions`
2. 服务把请求打包成 `prompt_request.txt` 文件，发到飞书群里
3. 群里的 AI 服务（wechat-claude-bot）看到文件，调 Claude，把结果写成 `prompt_response.txt` 回复
4. 服务拿到回复文件，解析后返回给你

## 部署步骤（一步一步来）

### 第 1 步：确认 Python 版本

需要 Python 3.12 或更高版本。

```bash
python3.12 --version
```

如果提示找不到命令，你需要先安装 Python 3.12。

### 第 2 步：把项目文件放到服务器上

把整个 `feishu-relay` 文件夹放到服务器上，比如放到 `/root/feishu-relay/`。

文件夹里应该有这些文件：
```
feishu-relay/
├── app.py              # 主程序
├── start.sh            # 启动脚本
├── test.sh             # 测试脚本
├── requirements.txt    # Python 依赖
├── README.md           # 你正在看的这个文件
└── CLAUDE.md           # 开发指引
```

### 第 3 步：安装依赖

```bash
cd /root/feishu-relay
python3.12 -m pip install -r requirements.txt
```

如果提示 pip 不存在，先装 pip：
```bash
python3.12 -m ensurepip
python3.12 -m pip install -r requirements.txt
```

### 第 4 步：确认配置

飞书应用和群的配置已经写死在代码里了，**不需要修改**，直接用就行。

**前提条件**（已满足，确认一下就好）：
- 飞书应用（机器人）已被加入到目标群里
- 群里有 AI 服务（wechat-claude-bot）在监听 `prompt_request.txt` 并回复 `prompt_response.txt`

### 第 5 步：启动服务

```bash
chmod +x /root/feishu-relay/start.sh
/root/feishu-relay/start.sh
```

看到下面的输出就是成功了：
```
Started (PID: xxxxx), log: /tmp/feishu-relay.log
{"status":"ok"}
```

### 第 6 步：验证服务正常

```bash
# 健康检查
curl http://127.0.0.1:9090/health
# 应该返回 {"status":"ok"}
```

### 第 7 步：发一个测试请求

```bash
curl -X POST http://127.0.0.1:9090/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "anthropic.claude-opus-4-6-v1",
    "messages": [{"role": "user", "content": "你好"}],
    "max_tokens": 100
  }'
```

等几秒到几十秒，应该返回类似：
```json
{
  "id": "chatcmpl-xxx",
  "choices": [{"message": {"role": "assistant", "content": "你好！..."}}]
}
```

如果超过 10 分钟没返回，看日志排查：
```bash
tail -50 /tmp/feishu-relay.log
```

## 常用命令

```bash
# 启动/重启服务
/root/feishu-relay/start.sh

# 查看实时日志
tail -f /tmp/feishu-relay.log

# 停止服务
pkill -f "feishu-relay/app.py"

# 跑测试
bash /root/feishu-relay/test.sh
```

## API 接口

### POST /v1/chat/completions

OpenAI 兼容的 chat completions 接口。请求格式和 OpenAI 一样：

```json
{
  "model": "随便写，会被自动替换成正确的模型",
  "messages": [
    {"role": "system", "content": "你是一个助手"},
    {"role": "user", "content": "你好"}
  ],
  "max_tokens": 1024
}
```

### GET /v1/models

返回模型列表。

### GET /health

健康检查。

## 工作原理细节

**请求-响应匹配**：服务发 `prompt_request.txt` 到群后会记住消息 ID。然后每 3 秒查一次群最近消息，找到文件名为 `prompt_response.txt` 且 `parent_id`（回复的父消息 ID）匹配的消息，就下载文件返回。超时 600 秒。

**为什么用轮询不用 WebSocket**：飞书的 WebSocket 事件订阅有个限制——app A 发的消息不会推送给 app B 的 WebSocket。所以两边都用轮询来发现新文件。

## 环境变量

| 变量 | 说明 | 默认值 |
|---|---|---|
| `FEISHU_APP_ID` | 飞书应用 App ID | `cli_a920d2534b78dcbd` |
| `FEISHU_APP_SECRET` | 飞书应用 App Secret | `bcAO7dO6vIftraPNBCKOMbTJcdSc8WlP` |
| `FEISHU_GROUP_CHAT_ID` | 飞书群 Chat ID | `oc_f5d386fdffce10b8c13af589dd62e833` |
| `RESPONSE_TIMEOUT` | 等待响应超时（秒） | `600` |
| `POLL_INTERVAL` | 轮询间隔（秒） | `3` |
| `PORT` | 服务端口 | `9090` |

## 出了问题怎么办

1. **请求一直没返回** → 看日志 `tail -50 /tmp/feishu-relay.log`，确认文件是否发到群里了
2. **飞书群里没收到文件** → 检查飞书应用权限和机器人是否在群里
3. **群里有 prompt_request.txt 但没有 prompt_response.txt** → 检查 AI 服务（wechat-claude-bot）是否在运行
4. **返回内容是空的** → 检查 model ID 是否正确（应该是 `anthropic.claude-opus-4-6-v1`）
