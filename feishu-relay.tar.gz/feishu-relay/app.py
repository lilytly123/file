"""
飞书中继 API 服务

伪装成 OpenAI 兼容的大模型 API，收到请求后：
1. 将请求写成 prompt_request.txt 发送到飞书群
2. 轮询群消息，等待 prompt_response.txt 回复
3. 将结果返回给调用方
"""

import json
import logging
import os
import time
import traceback

import requests
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

# ============================================================
# 配置
# ============================================================

FEISHU_APP_ID = os.getenv("FEISHU_APP_ID", "cli_a920d2534b78dcbd")
FEISHU_APP_SECRET = os.getenv("FEISHU_APP_SECRET", "bcAO7dO6vIftraPNBCKOMbTJcdSc8WlP")
FEISHU_GROUP_CHAT_ID = os.getenv("FEISHU_GROUP_CHAT_ID", "oc_f5d386fdffce10b8c13af589dd62e833")
FEISHU_BASE_URL = "https://open.feishu.cn"

RESPONSE_TIMEOUT = int(os.getenv("RESPONSE_TIMEOUT", "600"))
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "3"))  # 轮询间隔（秒）

# ============================================================
# 初始化
# ============================================================

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("feishu-relay")

app = FastAPI(title="Feishu Relay API")

_token_cache = {"token": "", "expire_at": 0}


# ============================================================
# 飞书 API 工具函数
# ============================================================


def get_tenant_token() -> str:
    now = time.time()
    if _token_cache["token"] and _token_cache["expire_at"] > now + 60:
        return _token_cache["token"]

    resp = requests.post(
        f"{FEISHU_BASE_URL}/open-apis/auth/v3/tenant_access_token/internal/",
        json={"app_id": FEISHU_APP_ID, "app_secret": FEISHU_APP_SECRET},
        timeout=10,
    )
    data = resp.json()
    if data.get("code") != 0:
        raise RuntimeError(f"Failed to get token: {data}")

    _token_cache["token"] = data["tenant_access_token"]
    _token_cache["expire_at"] = now + data.get("expire", 7200)
    log.info("Feishu token refreshed")
    return _token_cache["token"]


def upload_file(file_name: str, content: bytes) -> str:
    """上传文件到飞书，返回 file_key"""
    token = get_tenant_token()
    resp = requests.post(
        f"{FEISHU_BASE_URL}/open-apis/im/v1/files",
        headers={"Authorization": f"Bearer {token}"},
        data={"file_type": "stream", "file_name": file_name},
        files={"file": (file_name, content)},
        timeout=60,
    )
    result = resp.json()
    if result.get("code") != 0:
        raise RuntimeError(f"Upload failed: {result.get('msg')}")
    file_key = result["data"]["file_key"]
    log.info("Uploaded %s -> %s", file_name, file_key)
    return file_key


def send_file_to_group(file_key: str) -> str:
    """发送文件消息到飞书群，返回 message_id"""
    token = get_tenant_token()
    resp = requests.post(
        f"{FEISHU_BASE_URL}/open-apis/im/v1/messages?receive_id_type=chat_id",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={
            "receive_id": FEISHU_GROUP_CHAT_ID,
            "content": json.dumps({"file_key": file_key}),
            "msg_type": "file",
        },
        timeout=30,
    )
    result = resp.json()
    if result.get("code") != 0:
        raise RuntimeError(f"Send failed: {result.get('msg')}")
    msg_id = result["data"]["message_id"]
    log.info("Sent file to group, message_id=%s", msg_id)
    return msg_id


def get_recent_group_messages(page_size: int = 10) -> list:
    """获取群最近的消息列表"""
    token = get_tenant_token()
    resp = requests.get(
        f"{FEISHU_BASE_URL}/open-apis/im/v1/messages",
        headers={"Authorization": f"Bearer {token}"},
        params={
            "container_id_type": "chat",
            "container_id": FEISHU_GROUP_CHAT_ID,
            "page_size": page_size,
            "sort_type": "ByCreateTimeDesc",
        },
        timeout=15,
    )
    result = resp.json()
    if result.get("code") != 0:
        log.warning("Get messages failed: %s", result.get("msg"))
        return []
    return result.get("data", {}).get("items", [])


def download_file(message_id: str, file_key: str) -> bytes:
    """从飞书下载文件"""
    token = get_tenant_token()
    resp = requests.get(
        f"{FEISHU_BASE_URL}/open-apis/im/v1/messages/{message_id}/resources/{file_key}?type=file",
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Download failed: HTTP {resp.status_code}")
    return resp.content


def poll_for_response(sent_message_id: str, timeout: int = RESPONSE_TIMEOUT) -> dict | None:
    """轮询群消息，等待 parent_id 匹配的 prompt_response.txt"""
    start = time.time()
    while time.time() - start < timeout:
        try:
            messages = get_recent_group_messages(page_size=10)
            for msg in messages:
                if msg.get("msg_type") != "file":
                    continue
                # 检查是否是对我们发的消息的回复
                if msg.get("parent_id") != sent_message_id:
                    continue

                body_content = msg.get("body", {}).get("content", "")
                try:
                    parsed = json.loads(body_content)
                except (json.JSONDecodeError, TypeError):
                    continue
                if parsed.get("file_name") != "prompt_response.txt":
                    continue

                # 找到了 prompt_response.txt 回复
                reply_msg_id = msg.get("message_id", "")
                file_key = parsed.get("file_key", "")
                log.info("Found prompt_response.txt, reply_msg_id=%s, parent=%s", reply_msg_id, sent_message_id)

                file_data = download_file(reply_msg_id, file_key)
                response = json.loads(file_data.decode("utf-8"))
                choices = response.get("choices", [])
                if choices and choices[0].get("message", {}).get("content"):
                    return response
                else:
                    log.warning("Found prompt_response.txt but content is empty, skipping")
                    continue
        except Exception as e:
            log.warning("Poll error (will retry): %s", e)

        time.sleep(POLL_INTERVAL)

    return None


# ============================================================
# API 路由
# ============================================================


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """OpenAI 兼容的 chat completions 接口"""
    import asyncio

    body = await request.json()
    request_id = f"req_{int(time.time() * 1000)}"

    log.info("Received request %s, messages_count=%d", request_id, len(body.get("messages", [])))

    try:
        body["request_id"] = request_id
        body["model"] = "anthropic.claude-opus-4-6-v1"

        # 上传并发送 prompt_request.txt 到飞书群
        file_content = json.dumps(body, ensure_ascii=False, indent=2).encode("utf-8")
        file_key = upload_file("prompt_request.txt", file_content)
        msg_id = send_file_to_group(file_key)

        log.info("Polling for response, message_id=%s, timeout=%ds", msg_id, RESPONSE_TIMEOUT)

        # 在线程池中轮询等待响应（不阻塞 event loop）
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, poll_for_response, msg_id, RESPONSE_TIMEOUT)

        if result:
            log.info("Got response for %s", msg_id)
            return JSONResponse(content=result)
        else:
            log.warning("Timeout waiting for response, message_id=%s", msg_id)
            return JSONResponse(
                content={"error": {"message": "Response timeout", "type": "timeout"}},
                status_code=504,
            )

    except Exception as e:
        log.error("Request failed: %s\n%s", e, traceback.format_exc())
        return JSONResponse(
            content={"error": {"message": str(e), "type": "server_error"}},
            status_code=500,
        )


@app.get("/v1/models")
async def list_models():
    return {
        "object": "list",
        "data": [{"id": "feishu-relay", "object": "model", "owned_by": "relay"}],
    }


@app.get("/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "9090"))
    log.info("Starting relay API on port %d", port)
    uvicorn.run(app, host="0.0.0.0", port=port)
