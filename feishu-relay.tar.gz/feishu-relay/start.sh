#!/bin/bash
cd "$(dirname "$0")"

pkill -f "python3.12.*/feishu-relay/app.py" 2>/dev/null
# 也匹配相对路径启动的
lsof -ti:9090 | xargs kill 2>/dev/null
sleep 1

nohup python3.12 /root/feishu-relay/app.py > /tmp/feishu-relay.log 2>&1 &
echo "Started (PID: $!), log: /tmp/feishu-relay.log"

sleep 5
curl -s http://127.0.0.1:9090/health && echo "" || echo "FAILED to start"
tail -5 /tmp/feishu-relay.log
