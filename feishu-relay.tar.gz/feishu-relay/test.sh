#!/bin/bash
# 测试 feishu-relay 服务
# 发送一个简单的 OpenAI 格式请求，等待飞书群里的处理结果

echo "=== Sending request to feishu-relay ==="
echo "Waiting for response (may take a few minutes)..."
echo ""

curl -s -X POST http://127.0.0.1:9090/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "feishu-relay",
    "messages": [
      {"role": "user", "content": "1+1等于几？请用一个字回答。"}
    ],
    "max_tokens": 100
  }' | python3.12 -m json.tool

echo ""
echo "=== Done ==="
